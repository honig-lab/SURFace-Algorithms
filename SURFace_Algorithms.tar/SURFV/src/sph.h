      parameter (nver=2600,nfce=5200,nedge=7800)
      common /xyz/ ver(3,nver)
      common /fce/ nv,nf,fc(3,nfce),fcedg(3,nfce)
      common /edg/ ne,edg(6,nver),nedg(nver),edg2(2,nedge)
      integer nv,nf,fc,fcedg,edg,edg2
      integer nedg
      common /crdmd/fcemd(12,nfce)
      real tary(2)
