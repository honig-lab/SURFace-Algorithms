#include <sys/types.h>
#include <sys/times.h>
#include <time.h>
#include <pwd.h>

#define VERBOSE 0

float nx_cpuarr[2];

void etime(float *cpu)
{
    struct tms buf;

    times(&buf);
    nx_cpuarr[0] = (float)buf.tms_utime/(float)CLK_TCK;
    nx_cpuarr[1] = (float)buf.tms_stime/(float)CLK_TCK;
    cpu[0] = nx_cpuarr[0];
    cpu[1] = nx_cpuarr[1];
    if (VERBOSE) printf("ETIME: %6.3f %6.3f\n", cpu[0], cpu[1]);
}

void dtime(float *cpu)
{
    struct tms buf;
    
    times(&buf);
    nx_cpuarr[0] = (float)buf.tms_utime/(float)CLK_TCK;
    nx_cpuarr[1] = (float)buf.tms_stime/(float)CLK_TCK;
    cpu[0] = nx_cpuarr[0] - cpu[0];
    cpu[1] = nx_cpuarr[1] - cpu[1];
    if (VERBOSE) printf("DTIME: %6.3f %6.3f\n", cpu[0], cpu[1]);
}

void getlog(char *unam)
{
    struct passwd *pwp;
    
    pwp = getpwuid(getuid());
    strcpy(unam, pwp->pw_name);
    if (VERBOSE) printf("GETLOG: %s\n", unam);
}


