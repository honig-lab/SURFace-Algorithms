/* call to the C function realloc is necessary as memory is adjusted at
   run time 			S. Sridharan. Sep 95 */
#include <stdlib.h> 
#define memalloc memalloc_
void *memalloc( void **ptr, int *new_size )
{	void *newptr;   
	if(!*new_size) {
	  if(*ptr) free(*ptr);
	  return NULL;
	}
	if(!*ptr) {
	  newptr=malloc(*new_size);
	} else {
	  newptr=realloc(*ptr, *new_size);
	}
	if (newptr == 0 && *new_size != 0) {
          perror("memalloc", 8L);
	  exit(EXIT_FAILURE);
	}

	return newptr;
}
