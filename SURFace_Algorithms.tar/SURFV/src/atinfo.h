      include 'pointer.h'
      parameter (mxatm=50000,nrlist=1499,nrmax=1500)
      common /atmprm/ radt(nrmax)
     & /grid1/ nres,natm
     & /grid2/ radp,cbai,xo,yo,zo,lcb,mcb,ncb
     & /links/ irtot,irlink(nrlist),irnumb(nrlist)
     & /names/ rnam(nrmax),atnam(nrmax),rsnm(10000)
	real crd(3,1),r0(1)
      integer rsnm2(1)
      character*6 atnam
      character*3 rnam
      character*10 rsnm
      character*15 atmnm(1)
